from django.urls import path, include
from . import api_views

urlpatterns = [
    path('persons/', api_views.person_list),
    path('persons/<int:pk>/', api_views.person_detail),
    path('persons/update/<int:pk>/', api_views.person_update_delete),
    path('persons/delete/<int:pk>/', api_views.person_update_delete),
    path('stanowiska/', api_views.stanowisko_list),
    path('teams/', api_views.TeamList.as_view()),
    path('teams/<int:pk>/', api_views.TeamDetail.as_view()),
    path('osoby/', api_views.OsobaList.as_view()),
    path('osoby/<int:pk>/', api_views.OsobaDetail.as_view()),
    path('osoby/by_lastname/<str:phrase>/', api_views.osoba_get_by_lastname),
]