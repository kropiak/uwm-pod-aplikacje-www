from django.urls import path

# importujemy moduł views (plik views.py z tego samego katalogu co plik bieżący)
from . import views

# definiujemy zmienną urlpatterns, która jest listą mapowań adresów URL na nasze widoki
urlpatterns = [
    path("", views.welcome_view),
    path("persons", views.person_list, name='person-list'),
    path("person/<int:id>", views.person_detail, name='person-detail'),
    path("person/add", views.person_create, name='person-create'),
    path("person/<int:id>/change", views.person_update, name='person-update'),
    path("person/<int:id>/delete", views.person_delete, name='person-delete'),
]