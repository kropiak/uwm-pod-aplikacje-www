from django.http import Http404, HttpResponse
from django.shortcuts import redirect, render
import datetime

from .forms import PersonForm
from .models import Person


def welcome_view(request):
    return render(request,
                  "myapp/base.html")


def person_list(request):
    # jeżeli POST to znaczy, że wybrano opcję wyszukania obiektów
    if request.method == 'POST':
        persons = Person.objects.filter(lastname__icontains=request.POST['phrase'])
    else:
        # pobieramy wszystkie obiekty Person z bazy poprzez QuerySet
        persons = Person.objects.all()

    return render(request,
                  "myapp/person/list.html",
                  {'persons': persons})


def person_detail(request, id):
    # pobieramy konkretny obiekt Person
    try:
        person = Person.objects.get(id=id)
    except Person.DoesNotExist:
        raise Http404("Obiekt Person o podanym id nie istnieje")

    return render(request,
                  "myapp/person/detail.html",
                  {'person': person})


def person_create(request):
    if request.method == 'POST':
        form = PersonForm(request.POST)
        if form.is_valid():
            # zapisujemy obiekt do bazy
            person = form.save()
            # po dodaniu nastąpi przekierowanie do strony szczegółów tego obiektu
            return redirect('person-detail', person.id)
    else:
        form = PersonForm()

    return render(request,
                'myapp/person/create.html',
                {'form': form})


def person_update(request, id):
    try:
        person = Person.objects.get(id=id)
    except Person.DoesNotExist:
        raise Http404("Obiekt Person o podanym id nie istnieje")

    if request.method == 'POST':
        form = PersonForm(request.POST, instance=person)
        if form.is_valid():
            # zapisujemy obiekt do bazy
            person = form.save()
            # po dodaniu nastąpi przekierowanie do strony szczegółów tego obiektu
            return redirect('person-detail', person.id)
    else:
        form = PersonForm(instance=person)
        
    form = PersonForm(instance=person)
    return render(request,
                    'myapp/person/update.html',
                    {'form': form})


def person_delete(request, id):
    try:
        person = Person.objects.get(id=id)
        person.delete()
    except Person.DoesNotExist:
        raise Http404("Obiekt Person o podanym id nie istnieje")

    return redirect('person-list')
